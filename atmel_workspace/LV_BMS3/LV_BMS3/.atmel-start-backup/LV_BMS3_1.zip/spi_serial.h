/*
 * spi_serial.h
 *
 * Created: 2020-03-03 13:33:12
 *  Author: mat15mal
 */ 


#ifndef SPI_SERIAL_H_
#define SPI_SERIAL_H_



void SPI_test(void);

#endif /* SPI_SERIAL_H_ */